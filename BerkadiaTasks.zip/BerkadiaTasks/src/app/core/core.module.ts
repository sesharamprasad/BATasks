import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NavComponent } from './nav/nav.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import {MdIconRegistry,MaterialModule} from '@angular/material';
import { NgModule, Optional, SkipSelf,CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {} from './nav/nav.component'

@NgModule({
  imports: [
    RouterModule,CommonModule,FormsModule,MaterialModule.forRoot()
  ],
  exports: [
    RouterModule,FormsModule,MaterialModule,
    NavComponent,HeaderComponent,FooterComponent
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  declarations: [NavComponent,HeaderComponent,FooterComponent],
  providers: [MdIconRegistry]

})
export class CoreModule { @Optional() @SkipSelf() parentModule: CoreModule }

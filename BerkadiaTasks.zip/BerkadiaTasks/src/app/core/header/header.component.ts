import { Component, OnInit,Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: 'header.component.html',
  styleUrls: ['header.component.css']
})
export class HeaderComponent implements OnInit {
  title : string
  isDarkTheme: boolean
  constructor() {
    this.title ='Berkadia Code Tasks!'

  }
  @Output() notify: EventEmitter<boolean> = new EventEmitter<boolean>();

  ngOnInit() {
  }
  onClick() {

    this.isDarkTheme = !this.isDarkTheme
    this.notify.emit(this.isDarkTheme);
  }
}

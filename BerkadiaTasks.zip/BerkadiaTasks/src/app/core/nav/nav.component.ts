import { Component, OnInit ,Input } from '@angular/core';
import { Router } from '@angular/router';

class MenuItem {
  constructor(public caption: string, public link: any[]) { }
}

@Component({

  selector: 'story-nav',
  templateUrl: 'nav.component.html',
  styleUrls: ['nav.component.css']
})
export class NavComponent implements OnInit {
  menuItems: MenuItem[];
  @Input() title:string;
  ngOnInit() {
    this.menuItems = [
      { caption: 'Dashboard', link: ['/dashboard'] },
      { caption: 'Movies', link: ['/movies'] },
      { caption: 'Games', link: ['/games'] }
    ];
  }
  redirect(link:string) {
console.log("link: "+ link);
    this.router.navigate([link]);
  }
  constructor(private router: Router)
   {
  }


}


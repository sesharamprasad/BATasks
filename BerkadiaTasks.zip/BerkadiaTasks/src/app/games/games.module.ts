import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CardGamesService } from './shared/cardgames.service';
import { GamesRoutingModule,routedComponents } from './games-routing.module';
import { MaterialModule } from '@angular/material';
@NgModule({
  imports: [
    CommonModule, MaterialModule.forRoot(),GamesRoutingModule
  ],
  declarations: [routedComponents],
  providers: [CardGamesService]
})
export class GamesModule { }

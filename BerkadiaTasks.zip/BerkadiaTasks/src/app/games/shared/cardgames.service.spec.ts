import {MockBackend} from '@angular/http/testing';
import { CardGamesService } from './cardgames.service';
import { async, inject, TestBed } from '@angular/core/testing';
import { BaseRequestOptions, Http, HttpModule, Response, ResponseOptions } from '@angular/http';



describe('CardGamesService -Get drawnCards', () => {

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        CardGamesService,
        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backend, options) => new Http(backend, options),
          deps: [MockBackend, BaseRequestOptions]
        }
      ],
      imports: [
        HttpModule
      ]
    });
  });
  const mockResponse = [
    {
      remaining: 50,
      cards: [
        {
          images: {
            svg: "http://deckofcardsapi.com/static/img/2H.svg",
            png: "http://deckofcardsapi.com/static/img/2H.png"
          },
          value: "2",
          code: "2H",
          suit: "HEARTS",
          image: "http://deckofcardsapi.com/static/img/2H.png"
        },
        {
          images: {
            svg: "http://deckofcardsapi.com/static/img/KD.svg",
            png: "http://deckofcardsapi.com/static/img/KD.png"
          },
          value: "KING",
          code: "KD",
          suit: "DIAMONDS",
          image: "http://deckofcardsapi.com/static/img/KD.png"
        }
      ],
      deck_id: "m6tbnihgn7ys",
      success: true
    }
  ]

  it('should construct', async(inject(
    [CardGamesService, MockBackend], (service, mockBackend) => {

      expect(service).toBeDefined();
    })));

  /*it('should parse response and compare with mock respone data', async(inject(
    [CardGamesService, MockBackend], (service, mockBackend) => {

      mockBackend.connections.subscribe(conn => {
        conn.mockRespond(new Response(new ResponseOptions({ mockResponse })));
      });
      service.getDrawnCards()
        .subscribe(res => {
          expect(res.sucess).toEqual(mockBackend.success)
            ,
            error => {

              console.log('error occurred here');
              console.log(error);
              console.error(error)
            }
          // expect(res.id).toEqual(mockResponse.id)

        });
    })));*/
});

import { Injectable } from '@angular/core';
import { Http,Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/toPromise';
import  'rxjs/add/operator/map';
import  'rxjs/add/operator/catch';
import  'rxjs/add/observable/throw';
import { CONFIG} from '../../core/config';


@Injectable()
export class CardGamesService {

  private drawCardsUrl: string =CONFIG.API_Methods.DeckOfCards_GET_DrawCards.replace('{0}',CONFIG.baseUrls.DeckOfCards)
  private addDeckUrl: string = CONFIG.API_Methods.DeckOfCards_POST_AadDeck.replace('{0}',CONFIG.baseUrls.DeckOfCards)

  constructor(private http: Http) {
  }

  getAddDecks(){

    return <Observable<any>>this.http
      .get(`${this.addDeckUrl}`)
      .map(res => this.extractData<any>(res))
      .catch(this.handleError);

  }
  getDrawnCards(){

    return <Observable<any>>this.http
      .get(`${this.drawCardsUrl}`)
      .map(res => this.extractData<any>(res))
      .catch(this.handleError);

  }

  private handleError(error: Response) {
    console.error("ERROR in service");
    console.error(error);
    let msg = `Error status code ${error.status} at ${error.url}`;
    return Observable.throw(msg);
  }

  private extractData<T>(res: Response) {
    if (res.status < 200 || res.status >= 300) {
      throw new Error('Bad response status: ' + res.status);
    }
    let body = res.json ? res.json() : null;
    //console.log("extractData")
    //console.log(body)
    return <T>(body || {});
  }

}


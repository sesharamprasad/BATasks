/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { Observable } from 'rxjs/Observable';
import { CardGamesService} from './shared/cardgames.service';
import { GamesComponent } from './games.component';


class MockCardGamesService extends CardGamesService {
  constructor() {
    super(null);
  }

  getDrawnCards(){
    return Observable.of(
      {
        remaining: 50,
        cards: [
          {
            images: {
              svg: "http://deckofcardsapi.com/static/img/0D.svg",
              png: "http://deckofcardsapi.com/static/img/0D.png"
            },
            value: "10",
            code: "0D",
            suit: "DIAMONDS",
            image: "http://deckofcardsapi.com/static/img/0D.png"
          },
          {
            images: {
              svg: "http://deckofcardsapi.com/static/img/4D.svg",
              png: "http://deckofcardsapi.com/static/img/4D.png"
            },
            value: "4",
            code: "4D",
            suit: "DIAMONDS",
            image: "http://deckofcardsapi.com/static/img/4D.png"
          }
        ],
        "deck_id": "v4skhshhkbc1",
        "success": true
      }
    );
  }
}
describe('Games Component unit test', () => {
  var gameComponent: GamesComponent,
    gamesService: CardGamesService


  beforeEach(() => {
    gamesService = new MockCardGamesService();
    gameComponent = new GamesComponent(gamesService);
  });

  it('shows Drawn cards  by default - unit', () => {
    gameComponent.ngOnInit();
    expect(gameComponent.cards).toBeDefined();
    expect(gameComponent.cards[0].suit).not.toBeNull();
  });

});

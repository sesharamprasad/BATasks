import { BrowserModule } from '@angular/platform-browser';
import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { MaterialModule } from '@angular/material';
import { AppComponent ,SettingsDialog} from './app.component';
import { AppRoutingModule } from './app-routing.module';
import './core/rxjs-extension';
import { PageNotFoundComponent } from './page-not-found.component';
import { CoreModule } from './core/core.module';
@NgModule({
  declarations: [
    AppComponent,
    SettingsDialog,PageNotFoundComponent
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    // AppRoutingModule defines the catch-all ** route
    AppRoutingModule,
    MaterialModule.forRoot(),
    CoreModule
  ],
  entryComponents: [
    AppComponent,
    SettingsDialog
  ],
  exports :[MaterialModule],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }


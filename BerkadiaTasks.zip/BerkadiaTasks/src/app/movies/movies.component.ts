import { Component, OnInit,Pipe } from '@angular/core';
import {MovieService} from "./shared/movie.service";
import  "../core/rxjs-extension"
import {Movie,Credits,Cast} from './shared/movie.model'
import { CONFIG} from '../core/config';

@Component({

  selector: 'app-movies',
  templateUrl: './movies.component.html',
  styleUrls: ['./movies.component.css'],
  providers: [MovieService]
})
export class MoviesComponent implements OnInit {
  errorMessage: string;
  movieDetails:Movie;
  movieCasts:Cast[];
 apiKeyId:string
  constructor(private _movieservice: MovieService) { }
  getFaviorateMovies(){
  //  console.log("Get Movies triggerd");
   //this.movieDetails = [];
this._movieservice.getFavoriateMovieDetails()
    // .subscribe(movie=> =movie,
    // this.movieDetails  error=>this.errorMessage=<any> error
    //)
  .subscribe(
    (movie: Movie) => this.setFavoriteMovie(movie),
    error => {
      console.log('error occurred here');
      console.log(error);
    },
      () => {
        console.log('Faviorate Movie Details retrieval completed');
      }
  );

  }
    getCredits()
    {
      //console.log("Get getMovieCredits triggerd")
      this._movieservice.getMovieCredits()

        .subscribe(
          (movieCredits: any) => this.setMovieCredits(movieCredits),
          error => {
            console.log('error occurred here');
            console.log(error);
          },
          () => {
            console.log('Movie Credits retrieval completed');
          }
        );
    }
  private setFavoriteMovie(movie: Movie) {
    if (movie) {
      //console.log("Get setFavoriteMovie received data")
      this.movieDetails = movie;

    }
  }
  private setMovieCredits(credits: any) {
    //console.log("Get setMovieCredits recieved data triggerd")
    if (credits) {
      this.movieCasts =<Cast[]>credits.cast;
     //console.log(this.movieCasts)
    }
  }
  ngOnInit() {
    this.apiKeyId=CONFIG.baseUrls.MovieDB_APIKey;
    this.getFaviorateMovies();
    this.getCredits();
  }

}

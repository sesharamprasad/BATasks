import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MovieService } from './shared/movie.service';
import { MoviesRoutingModule,routedComponents } from './movies-routing.module';
import { MaterialModule } from '@angular/material';
@NgModule({
  imports: [
    CommonModule, MaterialModule.forRoot(),MoviesRoutingModule
  ],
  declarations: [routedComponents],
  providers: [MovieService]
})
export class MoviesModule { }

/* tslint:disable:no-unused-variable */
import {MockBackend, MockConnection} from '@angular/http/testing';
import { MovieService } from './movie.service';
import { async, inject, TestBed } from '@angular/core/testing';
import { BaseRequestOptions, Http, HttpModule, Response, ResponseOptions } from '@angular/http';
import { Subscription } from 'rxjs/Subscription';

export abstract class AbstractMockObservableService {
  protected _subscription: Subscription;
  protected _fakeContent: any;
  protected _fakeError: any;

  set error(err) {
    this._fakeError = err;
  }

  set content(data) {
    this._fakeContent = data;
  }

  get subscription(): Subscription {
    return this._subscription;
  }

  subscribe(next: Function, error?: Function, complete?: Function): Subscription {
    this._subscription = new Subscription();
    spyOn(this._subscription, 'unsubscribe');

    if (next && this._fakeContent && !this._fakeError) {
      next(this._fakeContent);
    }
    if (error && this._fakeError) {
      error(this._fakeError);
    }
    if (complete) {
      complete();
    }
    return this._subscription;
  }
}
describe('MovieService (Mocked)', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        MovieService,
        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backend, options) => new Http(backend, options),
          deps: [MockBackend, BaseRequestOptions]
        }
      ],
      imports: [
        HttpModule
      ]
    });
  });

  it('should construct', async(inject(
    [MovieService, MockBackend], (service, mockBackend) => {

      expect(service).toBeDefined();
    })));
});

/*describe('Service: Movie', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MovieService ,{useClass: MockBackend}
      ]
    });
  });

  it('should ...', inject([MovieService], (service: MovieService) => {
    expect(service).toBeTruthy();
  }));


  it('should get GetFavoriteMovie', inject([MovieService,MockBackend], (movieService,mockBackend) => {
       mockBackend.connections.subscribe(
      (connection: MockConnection) => {
       connection.mockRespond(new Response(
         new ResponseOptions({
             body: [
                {
                  adult: false,
                  backdrop_path: "/8uO0gUM8aNqYLs1OsTBQiXu0fEv.jpg",
                  belongs_to_collection: null,
                  budget: 63000000,
                  genres: [
                    {
                      id: 18,
                      name: "Drama"
                    }
                  ],
                  homepage: "http://www.foxmovies.com/movies/fight-club",
                  id: 550,
                  imdb_id: "tt0137523",
                  original_language: "en",
                  original_title: "Fight Club",
                  overview: "A ticking-time-bomb insomniac and a slippery soap salesman channel primal male aggression into a shocking new form of therapy. Their concept catches on, with underground \"fight clubs\" forming in every town, until an eccentric gets in the way and ignites an out-of-control spiral toward oblivion.",
                  popularity: 5.291959,
                  poster_path: "/adw6Lq9FiC9zjYEpOqfq03ituwp.jpg",
                  production_companies: [
                    {
                      name: "Regency Enterprises",
                      id: 508
                    }

                  ],
                  production_countries: [
                    {
                      iso_3166_1: "DE",
                      name: "Germany"
                    },
                    {
                      iso_3166_1: "US",
                      name: "United States of America"
                    }
                  ],
                  release_date: "1999-10-14",
                  revenue: 100853753,
                  runtime: 139,
                  spoken_languages: [
                    {
                      iso_639_1: "en",
                      name: "English"
                    }
                  ],
                  status: "Released",
                  tagline: "How much can you know about yourself if you've never been in a fight?",
                  title: "Fight Club",
                  video: false,
                  vote_average: 8.1,
                  vote_count: 5572
                }
              ]
            }
          )));
      });

    movieService.getFavoriateMovieDetails.subscribe((movie: Movie) => {
      expect(movie).toBeDefined();
      expect(movie.id).toBe(550);
    });

  }));}*/




import { Injectable } from '@angular/core';
import { Http,Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/toPromise';
import  'rxjs/add/operator/map';
import  'rxjs/add/operator/catch';
import  'rxjs/add/observable/throw';
import { Movie,Credits } from './movie.Model';
import { CONFIG} from '../../core/config';

@Injectable()
export class MovieService {

  private faviorateMovieUrl: string =CONFIG.API_Methods.MovieDB_GET_FaviorateMovie.replace('{0}',CONFIG.baseUrls.MovieDB).replace('{2}',CONFIG.baseUrls.MovieDB_APIKey)
  private movieCreditsUrl: string =CONFIG.API_Methods.MovieDB_GET_MovieCredits.replace('{0}',CONFIG.baseUrls.MovieDB).replace('{2}',CONFIG.baseUrls.MovieDB_APIKey)
    /*CONFIG.API_Methods.MovieDB_GET_Images*/


  constructor(private http: Http) {
  }

  getFavoriateMovieDetails(){
   // console.log("url: "+this.faviorateMovieUrl)
   return <Observable<Movie>>this.http
      .get(`${this.faviorateMovieUrl}`)
     .map(res => this.extractData<Movie>(res))
  .catch(this.handleError);
  }

  getMovieCredits(){
    //console.log("url: "+this.movieCreditsUrl)
    return <Observable<any>>this.http
      .get(`${this.movieCreditsUrl}`)
      .map(res => this.extractData<any>(res))
      //.toPromise()
      .catch(this.handleError);
  }

  private handleError(error: Response) {
    console.error("ERROR in service");
      console.log(error);
      let msg = `Error status code ${error.status} at ${error.url}`;
      return Observable.throw(msg);
    }

  private extractData<T>(res: Response) {
    if (res.status < 200 || res.status >= 300) {
      throw new Error('Bad response status: ' + res.status);
    }
    let body = res.json ? res.json() : null;
    //console.log("extractData")
    //console.log(body)
    return <T>(body || {});
  }

}

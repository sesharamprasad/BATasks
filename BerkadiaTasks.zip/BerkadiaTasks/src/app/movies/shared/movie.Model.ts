
export class Movie {
 adult: boolean;
   backdrop_path: string;
    belongs_to_collection: string;
    budget: string;

   homepage: string;
    id: number;
    imdb_id: string;
    original_language: string;
    original_title: string;
    overview: string;
    popularity: number;
    poster_path: string;
    release_date: string;
   revenue: number;
    runtime: number;
   status: string;
    tagline: string;
    title: string;
    video: boolean;
    vote_average: number;
    vote_count: number
}

export class Credits
{
  id :number;
  cast:Cast[];
  crew:Crew[];
}

export class Cast {
  cast_id: number;
  character: string;
  credit_id: string;
  id: string;
  name: string;
  order: number;
  profile_path: string;
}

export class Crew {
  credit_id: string;
  department: string;
  id: number;
  job: string;
  name: string;
  profile_path: string;
}

/* tslint:disable:no-unused-variable */

import { Observable } from 'rxjs/Observable';
import { MovieService} from './shared/movie.service';
import { MoviesComponent } from './movies.component';


class MockMovieService extends MovieService {
  constructor() {
    super(null);
  }

   getMovieCredits(){

    return Observable.of(
      {
        id: 652,
         cast: [
          {
            cast_id: 43,
            character: "Achilles",
            credit_id: "52fe4264c3a36847f801b083",
            id: 287,
            name: "Brad Pitt",
            order: 0,
            profile_path: "/kc3M04QQAuZ9woUvH3Ju5T7ZqG5.jpg"
          },
          {
            cast_id: 44,
            character: "Paris",
            credit_id: "52fe4264c3a36847f801b087",
            id: 114,
            name: "Orlando Bloom",
            order: 1,
            profile_path: "/vq90ECKinICxJYYZpbga4pMwch.jpg"
          },
          {
            cast_id: 45,
            character: "Hector",
            credit_id: "52fe4264c3a36847f801b08b",
            id: 8783,
            name: "Eric Bana",
            order: 2,
            profile_path: "/36As49OkTNvT96CzzjXNuKMeuyx.jpg"
          },
          {
            cast_id: 46,
            character: "King Agamemnon",
            credit_id: "52fe4264c3a36847f801b08f",
            id: 1248,
            name: "Brian Cox",
            order: 3,
            profile_path: "/kCNr8Q1T1xXFBsnxotNmFq5gozB.jpg"
          },
          {
            cast_id: 47,
            character: "Odysseus",
            credit_id: "52fe4264c3a36847f801b093",
            id: 48,
            name: "Sean Bean",
            order: 4,
            profile_path: "/iIxP2IzvcLgr5WaTBD4UfSqaV3q.jpg"
          },
          {
            cast_id: 48,
            character: "Menelaos",
            credit_id: "52fe4264c3a36847f801b097",
            id: 2039,
            name: "Brendan Gleeson",
            order: 5,
            profile_path: "/pUTBk2sqFgg4aFBXHckD0qKLUYP.jpg"
          },
          {
            cast_id: 49,
            character: "Helena",
            credit_id: "52fe4264c3a36847f801b09b",
            id: 9824,
            name: "Diane Kruger",
            order: 6,
            profile_path: "/cCVutSrGZg9kW2ux4hhvmm71ECJ.jpg"
          },
          {
            cast_id: 50,
            character: "Priam",
            credit_id: "52fe4265c3a36847f801b09f",
            id: 11390,
            name: "Peter O'Toole",
            order: 7,
            profile_path: "/7esSG4iZHueb5Nh8RBBhtRZLpom.jpg"
          },
          {
            cast_id: 51,
            character: "Briseis",
            name: "52fe4265c3a36847f801b0a3",
            id: 9827,
            credit_id: "Rose Byrne",
            order: 8,
            profile_path: "/laJdQNmsuR2iblYUggEqr49LvwJ.jpg"
          },
          {
            cast_id: 52,
            character: "Andromache",
            credit_id: "52fe4265c3a36847f801b0a7",
            id: 9825,
            name: "Saffron Burrows",
            order: 9,
            profile_path: "/wkhF0U1XLIrvACAYhvZ308l4yNR.jpg"
          },
          {
            cast_id: 53,
            character: "Patroclos",
            credit_id: "52fe4265c3a36847f801b0ab",
            id: 9828,
            name: "Garrett Hedlund",
            order: 10,
            profile_path: "/KJX3uhmLXoTaVrXFcjgCCv76qf.jpg"
          },
          {
            cast_id: 54,
            character: "Eudorus",
            credit_id: "52fe4265c3a36847f801b0af",
            id: 9831,
            name: "Vincent Regan",
            order: 11,
            profile_path: "/tiyjPHwmX8dMMfx0F8HUpXyLHeY.jpg"
          },
          {
            cast_id: 55,
            character: "Thetis",
            credit_id: "52fe4265c3a36847f801b0b3",
            id: 1666,
            name: "Julie Christie",
            order: 12,
            profile_path: "/73SExI7sunDfkSQmHQhUMryUSR2.jpg"
          },
          {
            cast_id: 56,
            character: "Nestor",
            credit_id: "52fe4265c3a36847f801b0b7",
            id: 940,
            name: "John Shrapnel",
            order: 13,
            profile_path: "/nDIK01IoVNx7cfYOrKqGugItqO9.jpg"
          },
          {
            cast_id: 57,
            character: "Ajax",
            credit_id: "52fe4265c3a36847f801b0bb",
            id: 9832,
            name: "Tyler Mane",
            order: 14,
            profile_path: "/ppGbITxSnakqHhZIqh5fTjQjq2D.jpg"
          },
          {
            cast_id: 62,
            character: "Boagrius",
            credit_id: "54ca547cc3a36879df00de19",
            id: 24898,
            name: "Nathan Jones",
            order: 15,
            profile_path: "/tNaBOoDSHBaqnoVG4bxShyGLZol.jpg"
          }
        ],
        crew: [
          {
            credit_id: "52fe4264c3a36847f801affb",
            department: "Directing",
            id: 5231,
            job: "Director",
            name: "Wolfgang Petersen",
            profile_path: "/t3Fxy4SBeOWj8T8TZbhwz3jlWAF.jpg"
          },
          {
            credit_id: "52fe4264c3a36847f801b001",
            department: "Writing",
            id: 9812,
            job: "Author",
            name: "Homer",
            profile_path: "/roXLV7QNLUvqP0lfa630rhtiZdP.jpg"
          },
          {
            credit_id: "52fe4264c3a36847f801b007",
            department: "Writing",
            id: 9813,
            job: "Screenplay",
            name: "David Benioff",
            profile_path: "/8CuuNIKMzMUL1NKOPv9AqEwM7og.jpg"
          },
          {
            credit_id: "52fe4264c3a36847f801b00d",
            department: "Production",
            id: 490,
            job: "Producer",
            name: "Colin Wilson",
            profile_path: null
          },
          {
            credit_id: "52fe4264c3a36847f801b013",
            department: "Production",
            id: 9814,
            job: "Producer",
            name: "Diana Rathbun",
            profile_path: null
          },
          {
            credit_id: "52fe4264c3a36847f801b019",
            department: "Production",
            id: 5231,
            job: "Producer",
            name: "Wolfgang Petersen",
            profile_path: "/t3Fxy4SBeOWj8T8TZbhwz3jlWAF.jpg"
          },
          {
            credit_id: "556f7c409251410866000a01",
            department: "Production",
            id: 9815,
            job: "Co-Producer",
            name: "Winston Azzopardi",
            profile_path: null
          },
          {
            credit_id: "52fe4264c3a36847f801b02b",
            department: "Sound",
            id: 1729,
            job: "Original Music Composer",
            name: "James Horner",
            profile_path: "/iEiRtIdTjlwxrh1dF27RFbLl9LD.jpg"
          },
          {
            credit_id: "52fe4264c3a36847f801b031",
            department: "Camera",
            id: 293,
            job: "Director of Photography",
            name: "Roger Pratt",
            profile_path: "/5a4fQyqEo5Mqq1QROrBxTy7urv1.jpg"
          },
          {
            credit_id: "56452be5c3a36870db0071d5",
            department: "Camera",
            id: 9816,
            job: "Camera Operator",
            name: "Paul Bond",
            profile_path: null
          },
          {
            credit_id: "52fe4264c3a36847f801b03d",
            department: "Editing",
            id: 6875,
            job: "Editor",
            name: "Peter Honess",
            profile_path: null
          },
          {
            credit_id: "52fe4264c3a36847f801b043",
            department: "Production",
            id: 1113,
            job: "Casting",
            name: "Lucinda Syson",
            profile_path: null
          },
          {
            credit_id: "52fe4264c3a36847f801b049",
            department: "Art",
            id: 9817,
            job: "Production Design",
            name: "Nigel Phelps",
            profile_path: null
          },
          {
            credit_id: "52fe4264c3a36847f801b04f",
            department: "Art",
            id: 9818,
            job: "Art Direction",
            name: "Julian Ashby",
            profile_path: null
          },
          {
            credit_id: "52fe4264c3a36847f801b055",
            department: "Art",
            id: 9819,
            job: "Art Direction",
            name: "Jon Billington",
            profile_path: null
          },
          {
            credit_id: "52fe4264c3a36847f801b05b",
            department: "Art",
            id: 9820,
            job: "Art Direction",
            name: "Andy Nicholson",
            profile_path: null
          },
          {
            credit_id: "52fe4264c3a36847f801b061",
            department: "Art",
            id: 9821,
            job: "Art Direction",
            name: "Marco Niro",
            profile_path: null
          },
          {
            credit_id: "52fe4264c3a36847f801b067",
            department: "Art",
            id: 9822,
            job: "Art Direction",
            name: "Adam O'Neill",
            profile_path: null
          },
          {
            credit_id: "52fe4264c3a36847f801b06d",
            department: "Art",
            id: 8384,
            job: "Set Decoration",
            name: "Anna Pinnock",
            profile_path: null
          },
          {
            credit_id: "52fe4264c3a36847f801b073",
            department: "Art",
            id: 9823,
            job: "Set Decoration",
            name: "Peter Young",
            profile_path: null
          },
          {
            credit_id: "52fe4264c3a36847f801b079",
            department: "Costume & Make-Up",
            id: 2530,
            job: "Costume Design",
            name: "Bob Ringwood",
            profile_path: null
          },
          {
            credit_id: "580a8c1d9251414e80002170",
            department: "Writing",
            id: 1453613,
            job: "Storyboard",
            name: "Martin Asbury",
            profile_path: null
          },
          {
            credit_id: "56452cf492514133ab00666c",
            department: "Sound",
            id: 21122,
            job: "Music Editor",
            name: "Ramiro Belgardt",
            profile_path: null
          },
          {
            credit_id: "570a7e0dc3a36877570050c6",
            department: "Art",
            id: 34513,
            job: "Supervising Art Director",
            name: "John King",
            profile_path: null
          },
          {
            credit_id: "570a7dfd92514155ed000518",
            department: "Art",
            id: 8382,
            job: "Supervising Art Director",
            name: "Kevin Phipps",
            profile_path: null
          },
          {
            credit_id: "570a7e1dc3a3681d24008bbc",
            department: "Art",
            id: 5021,
            job: "Supervising Art Director",
            name: "Leslie Tomkins",
            profile_path: null
          }
        ]
      }
    )
  }
  getFavoriateMovieDetails() {
  return Observable.of(
    {
      adult: false,
      backdrop_path: "/8uO0gUM8aNqYLs1OsTBQiXu0fEv.jpg",
      belongs_to_collection: null,
      budget: '63000000',
      homepage: "http://www.foxmovies.com/movies/fight-club",
      id: 550,
      imdb_id: "tt0137523",
      original_language: "en",
      original_title: "Fight Club",
      overview: "A ticking-time-bomb insomniac and a slippery soap salesman channel primal male aggression into a shocking new form of therapy. Their concept catches on, with underground \"fight clubs\" forming in every town, until an eccentric gets in the way and ignites an out-of-control spiral toward oblivion.",
      popularity: 5.291959,
      poster_path: "/adw6Lq9FiC9zjYEpOqfq03ituwp.jpg",
      release_date: "1999-10-14",
      revenue: 100853753,
      runtime: 139,
      status: "Released",
      tagline: "How much can you know about yourself if you've never been in a fight?",
      title: "Fight Club",
      video: false,
      vote_average: 8.1,
      vote_count: 5572
    }
  );

}
}
describe('Movie Component unit test', () => {
  var movieComponent: MoviesComponent,
    movieService: MovieService


  beforeEach(() => {
    movieService = new MockMovieService();
    movieComponent = new MoviesComponent(movieService);
  });

  it('shows favorite movie  by default - unit', () => {
    movieComponent.ngOnInit();
    expect(movieComponent.movieDetails).toBeDefined();
    expect(movieComponent.movieDetails.id).not.toBeNull();
  });


  it('shows favorite movie casts  by default - unit', () => {
    movieComponent.ngOnInit();
    expect(movieComponent.movieCasts).toBeDefined();
    expect(movieComponent.movieCasts.length).toBeGreaterThan(2)
  });
});

import { Component} from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
isDarkTheme: boolean;

  title = 'Berkadia Task works!';

  constructor() {}

  openDialog() {
    //const config = new MdDialogConfig();
    //config.viewContainerRef = this.vcr;
    //this.dialog.open(SettingsDialog, config);
  }
  onNotify(isDarkThemeChanage:boolean):void {
    this.isDarkTheme=isDarkThemeChanage
  }

}

@Component({
  selector: 'settings-dialog',
  template: `
    <label>like to see cast pics</label>
    <md-slide-toggle></md-slide-toggle>
  `
})
export class SettingsDialog {

}

///








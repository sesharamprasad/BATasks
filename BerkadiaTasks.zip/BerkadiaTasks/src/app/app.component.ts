import { Component, ViewChild, ViewContainerRef,Input } from '@angular/core';
import {MdSidenav, MdDialog, MdDialogConfig,MdMenuItem,} from "@angular/material";
import  { HeaderComponent} from './core/header/header.component'
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
 /* directives : [HeaderComponent]*/
})
export class AppComponent {
isDarkTheme: boolean;

  title = 'Berkadia Task works!';

  constructor() {}

  openDialog() {
    //const config = new MdDialogConfig();
    //config.viewContainerRef = this.vcr;
    //this.dialog.open(SettingsDialog, config);
  }
  onNotify(isDarkThem:boolean):void {
    this.isDarkTheme=isDarkThem
  }

}

@Component({
  selector: 'settings-dialog',
  template: `
    <label>like to see cast pics</label>
    <md-slide-toggle></md-slide-toggle>
  `
})
export class SettingsDialog {

}

///








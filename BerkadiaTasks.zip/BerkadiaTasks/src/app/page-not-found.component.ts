import { Component } from '@angular/core';
@Component({
  selector: 'Status-404',
  template: `
    <article class="template animated slideInRight">
      <h4>Inconceivable!</h4>
      <div>Requested page not available in the application.</div>
    </article>
  `
})

export class PageNotFoundComponent { }


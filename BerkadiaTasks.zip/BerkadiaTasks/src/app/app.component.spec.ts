/* tslint:disable:no-unused-variable */

import { TestBed, async,inject,ComponentFixture  } from '@angular/core/testing';
import { AppComponent } from './app.component';

/*describe('App: Berkadia', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [
        AppComponent
      ]
    });
  });

  it('should do something', async(() => {

    TestBed.compileComponents().then(() => {
      console.log("sadfasdfsaasfdf");
      const fixture = TestBed.createComponent(AppComponent);

      // Access the dependency injected component instance
      const app = fixture.componentInstance;
      console.log("sadfasdfsaasfdf2");
      //should create the app
      expect(app).toBeTruthy()

      console.log("sadfasdfsaasfdf3");
      //should have title berkadia code tasks
      expect(app.title).toEqual('Berkadia Code Tasks!');
      console.log("sadfasdfsaasfdf4");
      // Access the element
      const element = fixture.nativeElement;

      // Detect changes as necessary
      fixture.detectChanges();

      expect(element.textContent).toContain('Berkadia Code Tasks!');
    })
  }));
  /!*it('should create the app', async(() => {
    let fixture = TestBed.createComponent(AppComponent);
    let app = fixture.debugElement.componentInstance;

    console.log("news");
    expect(app).toBeTruthy();
  }));
*!/
  /!*it(`should have as title 'Berkadia Code Tasks!'`, async(() => {
    let fixture = TestBed.createComponent(AppComponent);
    let app = fixture.debugElement.componentInstance;
    expect(app.title).toEqual('Berkadia Code Tasks!');
  }));

  it('should render title in a h1 tag', async(() => {
    let fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
    let compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('h1').textContent).toContain('Berkadia Code Tasks!');
  }));*!/
});*/

///

describe('App: Berkadia', () => {
  let appComponent: AppComponent;
  let fixture: ComponentFixture<AppComponent>;
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AppComponent]
    });


    beforeEach(() => {
      fixture = TestBed.createComponent(AppComponent);
      appComponent = fixture.componentInstance;
      fixture.detectChanges();
    });

    it('should create', () => {
      expect(appComponent).toBeDefined();
    });

  });

});


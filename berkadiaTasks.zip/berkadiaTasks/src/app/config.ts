export let CONFIG = {
  baseUrls: {
    API_MovieDB_APIKey:'d7db9d5b6d42fb58e88bee84ed9c58fe',
    DeckOfCards:'https://deckofcardsapi.com',
    MovieDB:'https://api.themoviedb.org/3/movie'
     },

  API_Methods:{
    DeckOfCards_GET_DrawCards: '{0}/api/deck/new/draw/?count=2',
    DeckOfCards_POST_AadDeck: '{0}/api/deck/new/shuffle/',
    MovieDB_GET_FaviorateMovie: '{0}/550?api_key={2}',
    MovieDB_GET_MovieCredits: '{0}/550/credits?api_key={2}'

  }

};

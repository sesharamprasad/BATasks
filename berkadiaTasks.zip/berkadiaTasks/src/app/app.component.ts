import { Component, ViewChild, ViewContainerRef } from '@angular/core';
import {MdSidenav, MdDialog, MdDialogConfig,MdMenuItem,} from "@angular/material";
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Berkadia Task works!';

  constructor(public dialog: MdDialog, public vcr: ViewContainerRef) {}

  openDialog() {
    const config = new MdDialogConfig();
    config.viewContainerRef = this.vcr;
    this.dialog.open(SettingsDialog, config);
  }

}

@Component({
  selector: 'settings-dialog',
  template: `
    <label>like to see cast pics</label>
    <md-slide-toggle></md-slide-toggle>
  `
})
export class SettingsDialog {

}

///







import { Component, OnInit,Pipe } from '@angular/core';
import {MovieService} from "../shared/movie.service";
import  "../rxjs-extension"
import { Observable } from 'rxjs/observable';
import {Movie,Credits,Cast} from '../shared/movie.Model'


@Component({
  selector: 'app-movies',
  templateUrl: './movies.component.html',
  styleUrls: ['./movies.component.css'],
  providers: [MovieService]
})
export class MoviesComponent implements OnInit {
  errorMessage: string;
  movieDetails:Movie;
  movieCredits:Credits;
  movieCasts:Cast[];
  dogs = [
    {rows: 2, name: "Mal", human: "Jeremy", age: 5},
    {rows: 1, name: "Molly", human: "David", age: 5},
    { rows: 1, name: "Sophie", human: "Alex", age: 8},
    {rows: 2, name: "Taz", human: "Joey", age: '11 weeks'},
    { rows: 1, name: "Kobe", human: "Igor", age: 5},
    {rows: 2, name: "Porter", human: "Kara", age: 3},
    { rows: 1, name: "Stephen", human: "Stephen", age: 8},
    {rows: 1, name: "Cinny", human: "Jules", age: 3},
    { rows: 1, name: "Hermes", human: "Kara", age: 3},
  ];
  constructor(private _movieservice: MovieService) { }
  getFaviorateMovies(){
   //this.movieDetails = [];
this._movieservice.getFavoriateMovieDetails()
    // .subscribe(movie=> =movie,
    // this.movieDetails  error=>this.errorMessage=<any> error
    //)
  .subscribe(
    (movie: Movie) => this.setFavoriteMovie(movie),
    error => {
      console.log('error occurred here');
      console.log(error);
    },
      () => {
        console.log('Faviorate Movie Detaitls retrieval completed');
      }
  );

  }
    getCredits()
    {
      this._movieservice.getMovieCredits()
      // .subscribe(movie=> =movie,
      // this.movieDetails  error=>this.errorMessage=<any> error
      //)
        .subscribe(
          (movieCredits: any) => this.setMovieCredits(movieCredits),
          error => {
            console.log('error occurred here');
            console.log(error);
          },
          () => {
            console.log('Movie Credits retrieval completed');
          }
        );
    }
  private setFavoriteMovie(movie: Movie) {
    if (movie) {
      this.movieDetails = movie;

    }
  }
  private setMovieCredits(credits: any) {
    if (credits) {
      this.movieCasts =<Cast[]>credits.cast;
     console.log(this.movieCasts)
    }
  }
  ngOnInit() {
    this.getFaviorateMovies();
    this.getCredits();
  }

}

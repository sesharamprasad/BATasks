import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MovieService } from '../shared/movie.service';
import { MoviesRoutingModule,routedComponents } from './movies-routing.module';
import { MaterialModule } from '@angular/material';
@NgModule({
  imports: [
    CommonModule,MaterialModule,MoviesRoutingModule
  ],
  declarations: [routedComponents],
  providers: [MovieService]
})
export class MoviesModule { }

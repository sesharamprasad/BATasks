import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { NavComponent } from './nav.component';

import { NgModule, Optional, SkipSelf } from '@angular/core';

@NgModule({
  imports: [
     RouterModule,CommonModule
  ],
  exports: [
     RouterModule,
    [NavComponent]
  ],
  declarations: [NavComponent],
  providers: []
})
export class NavModule { }

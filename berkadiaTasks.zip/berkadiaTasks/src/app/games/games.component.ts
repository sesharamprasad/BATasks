import { Component, OnInit } from '@angular/core';
import {CardGamesService} from "../shared/cardgames.service";
@Component({
  selector: 'app-games',
  templateUrl: './games.component.html',
  styleUrls: ['./games.component.css'],
  providers: [CardGamesService]
})
export class GamesComponent implements OnInit {
  cards:any[];
  constructor(private _cardgameservice: CardGamesService) { }
  getAddDecks()
  {

  }
  refreshCards()
  {
    this.getDrawnCards()
  }
  getDrawnCards()
  {
    this._cardgameservice.getDrawnCards()
  .subscribe(
    (drawncards: any) => this.setDrawnCards(drawncards),
    error => {
      console.log('error occurred here');
      console.log(error);
    },
      () => {
        console.log('Draw Cards retrieval completed');
      }
  );
  }
  ngOnInit() {
    this.getDrawnCards()
  }
  private setDrawnCards(cards: any) {
    if (cards) {
      this.cards =cards.cards;
      console.log(this.cards)
    }
  }
}

import { BerkadiaTasksPage } from './app.po';

describe('berkadia-tasks App', function() {
  let page: BerkadiaTasksPage;

  beforeEach(() => {
    page = new BerkadiaTasksPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
